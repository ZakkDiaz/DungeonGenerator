﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DungeonRenderer
{
    public partial class Form1 : Form
    {
        private IDungeonGenerator generator;
        public Form1()
        {
            InitializeComponent();
            panel1.Paint += Panel1_Paint;
            generator = new DungeonGenerator();
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {
            using (var g = e.Graphics)
            {
                g.Clear(Color.Black);
                g.DrawImage(GenerateDungeon(), new PointF(0,0));
            }
        }

        private Bitmap GenerateDungeon()
        {
            var xVal = textBox1.Text;
            var yVal = textBox2.Text;
            int x = 10;
            int y = 10;
            Int32.TryParse(xVal, out x);
            Int32.TryParse(yVal, out y);
            x = x == 0 ? 10 : x;
            y = y == 0 ? 10 : y;
            generator.GenerateDungeon(x, y);
            return generator.Draw(panel1.Width, panel1.Height);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Invalidate();
        }
    }

    public class DungeonGenerator : IDungeonGenerator
    {
        private List<ITile> tiles;
        private Random r;

        public DungeonGenerator()
        {
            tiles = new List<ITile>();
            r = new Random();
        }

        public DungeonGenerator(int seed)
        {
            tiles = new List<ITile>();
            r = new Random(seed);
        }

        public Bitmap Draw(int width, int height)
        {
            var min = Math.Min(width, height);
            Bitmap bmp = new Bitmap(min, min);

            DrawDungeon(ref bmp);

            return bmp;
        }

        public void DrawDungeon(ref Bitmap bmp)
        {
            var maxX = tiles.Max(m => m.GetLocation().X);
            var maxY = tiles.Max(m => m.GetLocation().Y);
            var width = bmp.Width;
            var height = bmp.Height;
            var tileWidth = tiles.Count(c => c.GetLocation().X == 0);
            var tileHeight =tiles.Count(c => c.GetLocation().Y == 0);
            tileWidth = width / maxX;
            tileHeight = height / maxY;
            using (var g = Graphics.FromImage(bmp))
            {
                foreach (var tile in tiles)
                {
                    Point p = tile.GetLocation();
                    Color c = tile.GetColor();
                    var xStep = p.X / (float)maxX;
                    var yStep = p.Y / (float)maxY;
                    xStep *= width;
                    yStep *= height;
                    g.FillRectangle(new SolidBrush(c), xStep, yStep, tileWidth, tileHeight);
                }
            }
        }

        public void GenerateDungeon(int rows, int columns)
        {
            tiles.Clear();
            for (var i = 0; i < rows; i++)
            {
                for (var ii = 0; ii < columns; ii++)
                {
                    tiles.Add(GetTile(i, ii));
                }
            }
        }

        public ITile GetTile(int i, int ii)
        {
            if (i < ii)
                return new Tile(i, ii, Color.Green);
            else if(i > ii + 5)
                return new Tile(i, ii, Color.DarkGreen);
            else
                return new Tile(i, ii, Color.Blue);
        }
    }

    internal class Tile : ITile
    {
        private int _x;
        private int _y;
        private Color _color;

        public Tile(int x, int y, Color color)
        {
            _x = x;
            _y = y;
            _color = color;
        }

        public Color GetColor()
        {
            return _color;
        }

        public Point GetLocation()
        {
            return new Point(_x, _y);
        }
    }

    public interface ITile
    {
        Point GetLocation();
        Color GetColor();
    }

    public interface IDungeonGenerator
    {
        Bitmap Draw(int width, int height);
        void GenerateDungeon(int rows, int columns);
        ITile GetTile(int i, int ii);
    }
}
